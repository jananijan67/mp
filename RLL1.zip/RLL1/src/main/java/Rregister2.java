import java.sql.*;
import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
@WebServlet("/Rregister2")
public class Rregister2 extends HttpServlet
 {
	int cID;
	private static int idCounter = 1;
	

	public static synchronized int createID()
	{
	    return idCounter++;
	}    

    protected void doPost(HttpServletRequest req, HttpServletResponse res)throws ServletException, IOException 
{
        res.setContentType("text/html");
        PrintWriter out = res.getWriter();
       
	String a=req.getParameter("name");
	String b=req.getParameter("address");
	String c=req.getParameter("email");
	String d=req.getParameter("phone");
	String e=req.getParameter("password");
	 
 try 
{
	 Class.forName("oracle.jdbc.driver.OracleDriver");
	 Connection	 con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","1234");
	 PreparedStatement st=con.prepareStatement("insert into customer1 values(?,?,?,?,?,?)");
	 cID=createID();
	 st.setInt(1, cID); 
	 st.setString(2, a);				
	 st.setString(3, b);
	 st.setString(4,c);
	 st.setString(5, d);
	 st.setString(6, e);
	 int i=st.executeUpdate();
	 out.print("You are successfully registered..."); 
  if(i>0) 
   {
     res.sendRedirect("index.html");  
  }
  }
 	catch(Exception at)
 {}
              } 

 
 }

