import java.sql.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.io.IOException;
import java.sql.PreparedStatement;
import java.io.*;  
import javax.servlet.*;  
import javax.servlet.http.*;  
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.RequestDispatcher;

/**
 * Servlet implementation class loginCheck
 */
@WebServlet("/loginCheck")
public class loginCheck extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	String emailID, password;
    
	/**
     * @see HttpServlet#HttpServlet()
     */
    public loginCheck() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		 
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		emailID=request.getParameter("email");
		password=request.getParameter("password"); 
		
		try{  
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","1234");
			Statement stmt  =con.createStatement();
			PreparedStatement ps=con.prepareStatement("select * from customer1 where email=?");
			ps.setString(1, emailID);
			
			ResultSet rs=ps.executeQuery();
				while(rs.next())
				{	
					if(rs.getString(6).equals(password))
					{	
						response.sendRedirect("Welcome.jsp");
					}	
					else if(password.equals("Admin"))
					{	
						response.sendRedirect("view.jsp");
				    }else {
				    	
				    	response.sendRedirect("loginError.html");
				    }
				}	
			con.close();
		   }catch(Exception e){  e.printStackTrace();}
		
    }
	


}
