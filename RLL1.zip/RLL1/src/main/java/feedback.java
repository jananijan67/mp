import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import javax.servlet.annotation.WebServlet;
@WebServlet("/feedback")
public class feedback extends HttpServlet
{
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res)throws ServletException, IOException   
    {
        PrintWriter pw=res.getWriter();        //to print on the browser the response
        res.setContentType("text/html");
        String name=req.getParameter("name");
        String email=req.getParameter("email");
        String feedback=req.getParameter("feedback");
        try
        {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","1234");
        PreparedStatement ps=con.prepareStatement("insert into feedback values(?,?,?)");
        ps.setString(1,name);
        ps.setString(2,email);
        ps.setString(3,feedback);
        int i=ps.executeUpdate();
   	 System.out.print("Inserted successfully"); 
     if(i>0) 
      {
        res.sendRedirect("Checkout.jsp");  
     }
     }
    	catch(Exception at)
    {}
                 } 

    
    }
